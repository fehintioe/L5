// Custom JavaScript
// STEP 15: Call up the carousel using the id, and use the .carousel() method create the options object


// STEP 16: Change the interval to 5 seconds (set in milliseconds)
$(document).ready(function(){
    $('#myCarousel').carousel({
        interval: 5000  // 5 seconds
    });
});
// STEP 17: Try an even$(document).ready(function(){
    $('#myCarousel').on('slid.bs.carousel', function () {
        $('.carousel-caption').addClass('zoomed'); // Add zoom effect
    }).on('slide.bs.carousel', function () {
        $('.carousel-caption').removeClass('zoomed'); // Remove zoom effect when transitioning
    });
    document.addEventListener('keydown', function(e) {
        if (e.key === "ArrowLeft" || e.key === "ArrowRight") {
            e.preventDefault();
        }
    });
        
